Icon Pack — 900 Icons

This is placeholder seed content for local development.
In production this ZIP would contain the real source files.
